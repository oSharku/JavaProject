
package gajisebulan;
import java.util.Scanner;

public class GajiSebulan {

    public static void main(String[] args) {
    
        int hari;
        int gaji;
        int sehari = 160;
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan Nama: ");
        String nama = input.nextLine();
       
        do {
            System.out.print("Masukkan Bilangan Hari Bekerja : ");
            hari = input.nextInt();
            if (hari > 31) {
                System.out.println("Bilangan Hari Tidak Boleh Melebihi 31 Hari!");
            }
        } while (hari > 31);
        System.out.println("");
        System.out.println("");
        
        System.out.println("Rumusan Gaji Bulanan Bagi " + nama);
        System.out.println("Jumlah Hari Bekerja : " + hari);
        gaji = hari * sehari;
        System.out.println("Gaji Sebulan Adalah RM" + gaji);
    } 
}